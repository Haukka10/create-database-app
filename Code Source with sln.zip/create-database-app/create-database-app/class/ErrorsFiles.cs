﻿namespace DATABASE_useing_CSharp.P
{
    internal class ErrorsFiles
    {
        public string ErrorNamesFiles { get; set; }
        public string ErrorsFilesPath { get; set; }
        public int AllFiles { get; set; }
        public int CurrentFiles { get; set; }
    }
}
